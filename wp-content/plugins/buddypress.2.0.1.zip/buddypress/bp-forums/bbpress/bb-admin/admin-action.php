<?php
require_once('../bb-load.php');

bb_auth();
?>
